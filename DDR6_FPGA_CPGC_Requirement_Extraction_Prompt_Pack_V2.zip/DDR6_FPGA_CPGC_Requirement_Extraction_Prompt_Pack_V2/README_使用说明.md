# DDR6 FPGA CPGC-like Test Engine
## 历史算法代码需求反向提炼提示词包 V2

### 任务背景

我们正在设计一个运行在 FPGA 上的 DDR6 Memory Test / Traffic Generation Engine。

它可以参考 Intel CPGC 一类设计思想，但并不限定于 Intel，也不是要复刻某一家具体实现。

目标是从历史算法代码中反向提炼：

- 测试算法真正需要底层硬件提供什么能力；
- 哪些测试行为必须由 CPGC-like Test Engine 表达；
- 哪些功能属于 DDR6 MC；
- 哪些功能属于 PHY；
- 哪些参数、状态、错误信息和性能能力未来必须由 FPGA 支持。

本轮不是：
- 把软件代码“迁移”到 FPGA；
- 直接设计 RTL；
- 按历史类名/函数名照搬成硬件模块；
- 假设 Intel CPGC 的功能就是最终需求。

本轮是：

**历史算法代码 → 测试行为 → 通用硬件需求 → CPGC/MC边界 → FPGA方案输入**

---

# 推荐执行顺序

## 第 1 步

执行：

`01_历史算法代码到CPGC硬件需求_主提示词.md`

目标：
- 还原测试行为；
- 提取 Sequence / Address / Pattern / Traffic / Compare / Error / Config / Status 等能力；
- 输出第一版硬件需求。

## 第 2 步

执行：

`02_需求攻击式复核.md`

目标：
- 检查有没有漏需求；
- 检查有没有把软件实现细节误当硬件需求；
- 检查顺序依赖、状态、Expected Data、Outstanding、Error Capture、Reset/Stop/Pause 等隐含问题。

## 第 3 步

执行：

`03_CPGC_MC边界专项.md`

目标：
- 明确 CPGC-like Test Engine、DDR6 MC、PHY 各自职责；
- 找出哪些算法语义可能被 MC 重排破坏；
- 明确接口应该表达到 Memory Transaction 还是 DRAM Command。

## 第 4 步

执行：

`04_FPGA方案输入摘要.md`

目标：
把前面结果压缩成 FPGA 工程师可以直接用来写方案的输入。

---

# 最终建议交付给 FPGA 方案设计人员的文件

至少包括：

1. `01_TEST_BEHAVIOR.md`
2. `02_SEQUENCE_REQUIREMENTS.md`
3. `03_ADDRESS_REQUIREMENTS.md`
4. `04_DATA_PATTERN_REQUIREMENTS.md`
5. `05_TRAFFIC_REQUIREMENTS.md`
6. `06_COMPARE_ERROR_REQUIREMENTS.md`
7. `07_CONFIG_STATUS_REQUIREMENTS.csv`
8. `08_HARDWARE_REQUIREMENTS.csv`
9. `09_CPGC_MC_BOUNDARY.md`
10. `10_OPEN_QUESTIONS.md`
11. `11_ARCHITECTURE_INPUT_SUMMARY.md`
12. 攻击式复核结果

---

# 统一原则

1. Intel CPGC 只能作为参考，不允许因为“Intel一般这么做”而补需求。
2. 所有需求尽量能够追溯到：
   - 文件；
   - 类；
   - 函数；
   - 行号；
   - 配置项；
   - 调用关系。
3. 严格区分：
   - `CODE_CONFIRMED`
   - `INFERRED`
   - `UNKNOWN`
4. 软件线程、Queue、Buffer、Class、Object 等实现形式，不能直接映射成 FPGA 模块。
5. 必须把软件行为重新抽象成“硬件必须支持的能力”。
6. 必须重点识别：
   - Memory Transaction 顺序要求；
   - DRAM Command 顺序要求；
   - Expected Data 生成机制；
   - Read 返回关联；
   - 多 Channel / Rank / Bank 并发；
   - Compare 吞吐；
   - Error Capture；
   - Sequence 控制能力。
