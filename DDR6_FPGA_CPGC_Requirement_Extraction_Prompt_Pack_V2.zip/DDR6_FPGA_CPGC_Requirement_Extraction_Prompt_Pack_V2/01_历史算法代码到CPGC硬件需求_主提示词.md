# 历史算法代码 → DDR6 FPGA CPGC-like Test Engine 硬件需求
## 主分析提示词

# 一、任务定义

你正在分析一套历史 DDR / Memory Test 算法代码。

未来我们要在 FPGA 上实现一个 DDR6 Memory Test / Traffic Generation Engine。

它可以类比 Intel CPGC、Memory Traffic Generator、Pattern Generator、Sequence Engine、Memory BIST 等能力的组合，但最终功能必须来自实际业务需求和历史代码证据，不允许照抄任何厂商架构。

本轮目标不是代码迁移，不是 RTL 设计。

目标是：

> 从历史代码中反向恢复“测试算法真正要求底层 Test Engine 提供什么能力”，并整理成 FPGA 硬件方案可以直接使用的需求输入。

统一抽象链：

```text
历史算法代码
    ↓
测试行为
    ↓
硬件能力需求
    ↓
CPGC-like Test Engine
    ↓
DDR6 MC
    ↓
PHY
    ↓
DDR6 DRAM
```

---

# 二、证据等级

所有结论必须标记：

- `CODE_CONFIRMED`
  - 代码中有明确实现或调用证据。

- `INFERRED`
  - 可以根据多处代码合理推断，但没有直接定义。

- `UNKNOWN`
  - 当前代码无法确认，需要算法负责人或系统负责人确认。

禁止因为 DDR、CPGC、ALPG、MBIST 的行业常识自行补充需求。

---

# 三、第一部分：先还原算法到底在做什么

不要按照软件目录、类继承、函数调用树直接总结。

从 Memory Test 行为角度回答：

1. 一次测试如何开始？
2. 一次测试如何结束？
3. 测试由几个 Phase / Step / Loop 构成？
4. 每个 Phase 中：
   - 地址怎么变化？
   - 数据怎么变化？
   - Read / Write 怎么排列？
5. 是否存在：
   - 正向地址扫描；
   - 反向地址扫描；
   - 固定地址；
   - 随机地址；
   - 多层 Loop；
   - 条件跳转；
   - Stop on Error；
   - Continue on Error；
   - Repeat；
   - Timeout；
   - Trigger。
6. 哪些行为必须严格有序？
7. 哪些行为允许底层重新调度？
8. 是否存在上一笔访问影响下一笔访问的情况？
9. 软件最终得到什么结果？
10. 软件需要哪些错误信息？

输出：

`01_TEST_BEHAVIOR.md`

至少选择 5~10 个代表性测试场景，用步骤描述。

例如：

```text
Phase 0:
  地址从 START 到 END
  对每个地址写入 Pattern A

Phase 1:
  地址从 END 到 START
  对每个地址读取
  根据地址重新生成 Expected Data
  Compare
  如果错误则记录 Fail Address
```

必须以真实代码为准。

---

# 四、第二部分：Sequence Engine 需求

重点分析测试序列到底需要多复杂。

检查：

- 单 Phase；
- 多 Phase；
- Phase 顺序；
- Phase Repeat；
- 全局 Loop；
- 局部 Loop；
- 嵌套 Loop；
- 条件跳转；
- Error 条件跳转；
- Count 条件跳转；
- 时间条件；
- 地址完成条件；
- Pattern 完成条件；
- Barrier；
- 多 Engine 同步；
- Start；
- Stop；
- Pause；
- Resume；
- Abort；
- Restart。

对每一种真实存在的能力输出：

| SEQ_REQ_ID | 需求 | 行为说明 | 输入 | 状态 | 退出条件 | 代码证据 | 证据等级 |
|---|---|---|---|---|---|---|---|

特别回答：

1. 历史算法是否只需要固定流程？
2. 是否需要可编程 Sequence？
3. 是否存在类似“微指令”的表达需求？
4. 是否需要嵌套 Loop？
5. 最大 Loop 层级能否从代码确定？
6. Sequence 是否依赖 Compare 结果？
7. Sequence 是否依赖地址生成完成事件？

输出：

`02_SEQUENCE_REQUIREMENTS.md`

---

# 五、第三部分：Address Generator 需求

从代码中找出所有地址行为。

重点检查：

- Start Address
- End Address
- Fixed Address
- Increment
- Decrement
- Stride
- Wrap
- Repeat
- Address Mask
- Random
- PRBS / LFSR Address
- Walking Address
- Bit Toggle
- Address XOR
- Address permutation
- 多层嵌套地址循环
- Bank切换
- Row切换
- Column切换
- Rank切换
- Channel切换
- Sub-channel切换

如果存在物理 DRAM 地址拆分，分析：

```text
Channel
Sub-channel
Rank
Bank Group
Bank
Row
Column
Burst / Offset
```

每个地址模式输出：

| ADDR_REQ_ID | 模式 | 数学规则 | 初始条件 | 下一地址规则 | Wrap条件 | 参数 | 代码证据 | 证据等级 |
|---|---|---|---|---|---|---|---|---|

重点回答：

1. 算法看到的是 Linear Address 还是 DRAM Geometry？
2. 是否允许直接指定 Rank/Bank/Row/Column？
3. Address Pattern 是否会依赖当前 Phase？
4. Address Pattern 是否会依赖 Data Pattern？
5. 地址生成是否需要 1 request/cycle 级吞吐？
6. 多 Channel 是否需要独立 Address Generator？
7. 多 Engine 是否需要独立地址状态？

输出：

`03_ADDRESS_REQUIREMENTS.md`

---

# 六、第四部分：Data Pattern Generator 需求

寻找所有 Data Pattern。

至少检查：

- All 0
- All 1
- Checkerboard
- Inverse Checkerboard
- Walking 1
- Walking 0
- Fixed Pattern
- User Pattern
- Increment Pattern
- Address-as-Data
- Inverted Address
- PRBS
- LFSR
- Random
- Toggle Pattern
- Beat相关Pattern
- Burst内Pattern
- Byte相关Pattern
- DQ bit相关Pattern
- 相邻地址相关Pattern
- 相邻数据相关Pattern
- 历史状态相关Pattern

每个 Pattern 输出：

| DATA_REQ_ID | Pattern | 生成规则 | Seed | 内部状态 | 每Beat变化 | 每Burst变化 | 每Address变化 | 代码证据 |
|---|---|---|---|---|---|---|---|---|

重点回答：

## Expected Data 怎么得到？

判断实际代码属于哪一种或哪几种：

A. Read 时重新计算  
B. Write Data 保存后再读出  
C. 根据 Address + Seed 重建  
D. 根据 Sequence 状态重建  
E. Pattern Generator 保留历史状态  
F. 软件直接提供 Expected Data  
G. 其他

必须说明：

- Expected Data 是否需要与 Read 返回严格关联；
- 是否允许 out-of-order Read Return；
- 是否需要保存每笔请求的 Pattern Context；
- 是否存在 Compare Mask。

输出：

`04_DATA_PATTERN_REQUIREMENTS.md`

---

# 七、第五部分：Traffic / Operation Generator 需求

历史代码最终对 Memory 发出了什么类型的行为？

检查：

- WRITE
- READ
- READ + COMPARE
- WRITE → READ
- READ → WRITE
- READ → MODIFY → WRITE
- N Write : M Read
- 同地址重复访问
- 多地址连续访问
- 随机访问
- Burst访问
- Bank交错访问
- Rank交错访问
- Channel并行访问

必须区分两层：

## Memory Transaction 层

例如：

```text
WRITE address X data Y
READ address X
```

## DRAM Command 层

例如：

```text
ACT
RD
WR
PRE
REF
```

重点回答：

### 1.
历史算法真正要求的是哪一级？

### 2.
如果算法要求：

“先写完整个地址空间，再反向读取”

这是 Transaction 顺序还是 DRAM Command 顺序？

### 3.
如果算法要求：

“同一个 Bank 连续特定访问”

它要求的是：

- 固定 Memory Transaction 顺序；
还是
- 固定 ACT/RD/WR/PRE 顺序？

### 4.
是否存在 MC 自由调度会破坏测试语义的场景？

### 5.
是否存在必须禁止：
- Reorder；
- Merge；
- Row-hit优化；
- Command重新排序；
的场景？

输出：

`05_TRAFFIC_REQUIREMENTS.md`

---

# 八、第六部分：Compare / Checker / Error 需求

分析所有：

- Expected Data
- Actual Data
- Compare
- Compare Mask
- Byte Mask
- Bit Mask
- Error Bitmap
- Fail Address
- Fail Data
- Expected Data
- Error Counter
- First Error
- Last Error
- Error Threshold
- Stop on Error
- Continue on Error
- Error Overflow
- Error Timestamp
- Phase ID
- Pattern ID
- Loop ID
- Rank/Bank/Row/Column
- Beat Index
- Burst Index

输出：

| CMP_REQ_ID | 能力 | 输入 | 行为 | 输出 | 保存状态 | 最大数量/深度 | 清除条件 | 代码证据 |
|---|---|---|---|---|---|---|---|---|

重点回答：

1. Compare 是否必须线速？
2. 是否允许 Compare Backpressure？
3. 如果 Read Return 很快，错误信息如何保存？
4. 是否只需要 PASS/FAIL？
5. 软件是否依赖详细 Fail Record？
6. Fail Record 至少需要哪些字段？
7. 错误很多时是：
   - 全保存；
   - 只保存前 N 条；
   - 只保存 First Error；
   - 只保存计数；
   - 其他？
8. Counter 是否可能溢出？
9. 错误出现后 Sequence 是否发生变化？

输出：

`06_COMPARE_ERROR_REQUIREMENTS.md`

---

# 九、第七部分：配置、状态、控制接口需求

扫描：

- Config Class
- Struct
- Enum
- API
- CLI
- JSON/XML/YAML
- Register-like定义
- 常量
- Macro
- 控制函数
- Status
- Result

不要简单照搬软件字段。

需要重新解释成：

> 哪些“用户可配置行为”未来必须由 FPGA Test Engine 表达？

输出：

`07_CONFIG_STATUS_REQUIREMENTS.csv`

字段：

```text
CFG_ID
Category
Parameter
Meaning
Type
Required_Width
Default
Legal_Range
When_Effective
Runtime_Change
Reset_Value
Status_or_Config
Evidence_File
Evidence_Function
Evidence_Line
Evidence_Level
```

位宽没有证据时写 `TBD`。

---

# 十、第八部分：并发与性能需求

重点寻找：

- 多 Channel
- 多 Sub-channel
- 多 Rank
- 多 Bank
- 多 Test Engine
- Parallel Test
- Outstanding
- Queue
- Pipeline
- Async
- Batch
- Buffer
- 多线程

注意：

软件多线程不等于 FPGA 必须多 Engine。

对每个并发特征判断：

- 算法语义必须；
- 软件性能优化；
- 多 Memory 实例；
- 多 Channel；
- 与硬件无关；
- UNKNOWN。

提取真实能够证明的性能要求：

- 请求生成速率；
- 最大 Outstanding；
- Compare 吞吐；
- Read Return 吞吐；
- 是否允许 Backpressure；
- Buffer 深度；
- 测试时间；
- 最大 Loop 次数；
- Counter 范围；
- 多 Channel 同步要求。

无法证明时写 UNKNOWN。

---

# 十一、第九部分：从行为转换成“硬件需求”

现在开始把前面结果抽象成 FPGA 硬件需求。

注意：

不要写 RTL 实现方案。

错误：

> 使用 32 深度 FIFO 保存错误。

正确：

> 在软件不能及时读取错误信息的情况下，Test Engine 需要保证规定数量的 Fail Record 不丢失；所需缓存能力当前为 TBD。

每条需求采用：

```text
REQ-xxx

需求名称：
需求类别：

需求描述：

触发条件：

输入：

要求行为：

输出：

需要保持的状态：

配置项：

边界条件：

异常处理：

性能要求：

顺序约束：

与MC关系：

与PHY关系：

代码证据：

证据等级：
CODE_CONFIRMED / INFERRED / UNKNOWN

Open Question：
```

统一汇总到：

`08_HARDWARE_REQUIREMENTS.csv`

字段至少包括：

```text
REQ_ID
Category
Requirement
Trigger
Input
Behavior
Output
State
Configuration
Boundary
Ordering
Performance
MC_Relationship
PHY_Relationship
Evidence_File
Evidence_Function
Evidence_Line
Evidence_Level
Open_Question
```

---

# 十二、第十部分：识别 CPGC-like Test Engine 能力集合

不要直接设计模块。

先按“能力”归类需求。

检查是否真实需要：

- Test Control
- Sequence Control
- Address Generation
- Data Pattern Generation
- Expected Data Generation
- Operation / Traffic Generation
- Request Issue
- Read Return Tracking
- Compare Engine
- Error Capture
- Statistics
- Configuration
- Status
- Trigger
- Synchronization
- Performance Monitor

对每项输出：

| 能力 | 是否需要 | 对应REQ | 为什么需要 | 是否实时路径 | 可否软件完成 | 与MC边界 |
|---|---|---|---|---|---|---|

---

# 十三、第十一部分：必须主动寻找架构 Blocker

站在 FPGA 工程师准备写方案的角度，检查代码没有回答但必须知道的问题。

至少包括：

- Test Engine 数量？
- 每 Channel 一个 Engine 还是共享？
- 多 Channel 能否跑不同 Pattern？
- 多 Channel 是否需要同步开始？
- 多 Rank 是否独立？
- Address Generator 数量？
- Pattern Generator 数量？
- Sequence Engine 是否共享？
- 是否需要可编程 Sequence RAM？
- Sequence 最大长度？
- Loop 最大嵌套层数？
- Loop Counter 位宽？
- Pattern Seed 位宽？
- PRBS 多项式是否可配置？
- Compare 是否必须线速？
- 是否允许 Read Return Backpressure？
- Outstanding 最大数量？
- Read Return 是否可能乱序？
- 如何关联 Expected Data？
- Fail Record 最少保存多少条？
- Error Counter 位宽？
- 配置更新何时生效？
- 是否需要 Shadow Config？
- Test 中途允许改配置吗？
- Pause/Resume 语义？
- Stop 后 Outstanding 如何处理？
- Abort 与 Graceful Stop 区别？
- Reset 后哪些状态清零？
- 测试中 Reset 如何处理？
- 是否需要外部 Trigger？
- 是否需要多个 Engine Barrier？
- 是否需要中断？
- 软件轮询还是中断？
- Test 最长运行时间？
- 性能 Counter 需求？

不能从代码证明就写：

`OPEN QUESTION`

输出：

`10_OPEN_QUESTIONS.md`

---

# 十四、最终总结

最后生成：

`11_ARCHITECTURE_INPUT_SUMMARY.md`

只回答 FPGA 工程师最需要的内容：

## 1. 这套历史算法本质上需要一个什么样的 Test Engine？

不要用历史项目内部名。

## 2. 它需要哪些核心能力？

例如：

```text
Sequence
Address
Pattern
Traffic
Compare
Error
Config
Status
```

但只能列有证据的。

## 3. 哪些能力必须进入实时硬件路径？

## 4. 哪些能力可以继续留在 Host / Software？

## 5. 当前最关键的 10 个架构 Blocker 是什么？

## 6. 哪些需求会显著影响：
- FPGA资源；
- 时序；
- BRAM/URAM；
- 多 Channel 扩展；
- 接口宽度；
- 状态机复杂度；
- 验证复杂度？

## 7. 给出当前需求视角下的逻辑链：

```text
Host / Software
    ↓
CPGC-like Test Engine
    ↓
DDR6 MC
    ↓
DFI / PHY
    ↓
DDR6 DRAM
```

只写功能边界，不设计 RTL。

---

# 最终禁止事项

- 不要因为 Intel CPGC 有某功能，就默认我们的设计需要。
- 不要把历史软件 Class 一一翻译成 RTL 模块。
- 不要把线程数直接翻译成 Engine 数量。
- 不要自行决定 FIFO 深度。
- 不要自行决定寄存器位宽。
- 不要自行决定 Sequence RAM 深度。
- 不要自行决定 Outstanding 数量。
- 不要把推测写成确定需求。
