# DDR6 FPGA CPGC-like Test Engine
## CPGC-like Test Engine 与 DDR6 MC 边界专项提示词

本轮只分析功能边界和语义边界。

不要设计 RTL。
不要假设 Intel CPGC 的边界就是我们的边界。
以历史算法真实需求和现有 DDR6 MC 分工为准。

---

# 一、统一功能层级

分析每项行为属于哪一级：

## Level 0：Host / Test Software

例如：
- Test Case选择
- Test Plan
- 参数配置
- 结果读取
- 日志

## Level 1：CPGC-like Test Intent / Sequence

例如：
- Phase
- Loop
- 地址方向
- Pattern选择
- Read/Write顺序

## Level 2：Memory Transaction

例如：
- WRITE address/data
- READ address
- READ_COMPARE

## Level 3：DDR6 MC Command Scheduling

例如：
- ACT
- RD
- WR
- PRE
- REF
- Timing constraint
- Bank state

## Level 4：DFI / PHY

例如：
- DFI timing
- training
- serialization
- IO timing

---

# 二、逐项 Ownership 判断

针对下列功能给出：

`CPGC_OWNED / MC_OWNED / PHY_OWNED / SHARED / UNKNOWN`

并给出理由和代码证据。

检查项：

- Test Start
- Test Stop
- Pause
- Resume
- Abort
- Phase
- Sequence
- Loop
- Address Range
- Address Traversal
- Address Mapping
- Channel选择
- Rank选择
- Bank选择
- Row选择
- Column选择
- Pattern Generation
- Expected Data
- Read/Write选择
- Read/Write顺序
- Transaction Dependency
- Outstanding
- Request ID
- Read Return Tracking
- Compare
- Error Capture
- Error Counter
- Performance Counter
- ACT生成
- RD生成
- WR生成
- PRE生成
- Refresh
- Bank State
- DDR Timing Constraint
- Command Arbitration
- Row-hit优化
- Command Reorder
- DFI
- PHY Timing
- Training

输出：

| 功能 | Ownership | 理由 | 算法是否依赖 | MC自由度 | 代码证据 |
|---|---|---|---|---|---|

---

# 三、重点回答接口抽象层级

分析当前历史算法最自然的硬件接口是：

### 方案A：Memory Transaction接口

例如：

```text
WRITE addr data
READ addr
```

### 方案B：DRAM Command接口

例如：

```text
ACT
RD
WR
PRE
```

### 方案C：两种模式都需要

### 方案D：当前代码无法确定

不要选你认为“设计最好”的答案。

只根据算法语义判断。

---

# 四、找出 MC 不能破坏的算法语义

列出所有：

> 如果 MC 自由调度、乱序、合并或优化，可能改变测试意义的场景。

逐项说明：

- 原测试行为；
- MC可能做的变化；
- 为什么会破坏测试语义；
- 是否需要强制顺序；
- 是否需要 Barrier；
- 是否需要 No-Reorder；
- 是否需要 Command-level控制。

---

# 五、找出完全可以交给 MC 的内容

列出：

> 算法并不关心底层 ACT/PRE/Refresh/Timing，只要求最终 Memory Transaction 正确完成的场景。

这些场景尽量交给 MC，而不是 CPGC-like Test Engine 重复实现。

---

# 六、最终逻辑边界

输出：

`09_CPGC_MC_BOUNDARY.md`

包括：

```text
Host / Software
       ↓
CPGC-like Test Engine
       ↓
<当前最合适的抽象接口>
       ↓
DDR6 MC
       ↓
DFI
       ↓
PHY
       ↓
DDR6 DRAM
```

分别说明每层：

- 输入；
- 输出；
- 负责的状态；
- 不负责的内容；
- 不能跨越的语义边界。

---

# 七、必须单列 Open Questions

例如：

- 是否需要 DRAM Command-level Test？
- 是否允许 MC Reorder？
- 是否需要 bypass scheduler？
- 是否需要 Row-hit关闭模式？
- 是否需要固定 Bank访问顺序？
- 是否需要固定 ACT/RD/WR/PRE 间隔？
- 是否需要人为插入 timing margin？
- 是否需要产生协议非法/边界压力序列？

如果历史代码无法证明，写 UNKNOWN，不要自行决定。
