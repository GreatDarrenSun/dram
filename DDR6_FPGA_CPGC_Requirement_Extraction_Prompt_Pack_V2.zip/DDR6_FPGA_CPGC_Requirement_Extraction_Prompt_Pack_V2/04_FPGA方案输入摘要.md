# DDR6 FPGA CPGC-like Test Engine
## FPGA方案输入摘要生成提示词

请基于前面已经完成的：

- Test Behavior
- Sequence Requirements
- Address Requirements
- Data Pattern Requirements
- Traffic Requirements
- Compare/Error Requirements
- Config/Status Requirements
- Hardware Requirements
- CPGC/MC Boundary
- Open Questions
- 攻击式复核结果

生成一份面向 FPGA 工程师的方案输入摘要。

本轮仍然不要直接写 RTL 详细设计。

---

# 一、项目目标

用 3~5 句话说明：

未来 FPGA 中需要实现的 CPGC-like Test Engine 到底承担什么任务。

不要使用历史软件架构术语。

---

# 二、核心能力表

输出：

| 能力域 | 需要的能力 | 关键参数 | 实时性要求 | 证据等级 | 对FPGA架构影响 |
|---|---|---|---|---|---|

能力域至少考虑：

- Test Control
- Sequence
- Address
- Pattern
- Traffic
- Request Issue
- Read Return Tracking
- Compare
- Error Capture
- Statistics
- Config
- Status
- Trigger
- Multi-channel
- Performance

---

# 三、关键数据通路

根据需求描述以下逻辑数据流，但不要做 RTL 模块定型：

```text
Config
  ↓
Test/Sequence
  ↓
Address + Pattern + Operation
  ↓
Request
  ↓
DDR6 MC
  ↓
Read Return
  ↓
Expected Data / Compare
  ↓
Error / Statistics
```

指出每一步必须携带哪些 Context。

特别关注：

- Address
- Pattern ID
- Phase ID
- Loop ID
- Expected Data context
- Request ID
- Channel/Rank/Bank信息

---

# 四、关键状态

列出 FPGA 未来很可能需要维护的状态：

例如：

- 当前 Phase
- 当前 Loop
- 当前 Address
- 当前 Pattern
- Seed
- Outstanding
- Request Context
- Error Count
- First Error
- Run State

这里只列需求能够证明的状态。

---

# 五、最影响总体架构的需求

按影响类型分类：

## 会影响数据通路宽度
## 会影响 BRAM/URAM
## 会影响 LUT/FF
## 会影响时序
## 会影响多 Channel 扩展
## 会影响 MC 接口
## 会影响验证复杂度

每项引用对应 REQ_ID。

---

# 六、架构 Blocker

输出：

| BLOCKER_ID | 问题 | 为什么现在必须确认 | 影响模块 | 不同答案可能导致的架构差异 |
|---|---|---|---|---|

只保留真正影响总体架构的问题。

---

# 七、给 FPGA 方案设计阶段的建议输入

最终输出：

`11_ARCHITECTURE_INPUT_SUMMARY.md`

并附：

## 已经可以开始设计的部分

## 暂时只能预留接口的部分

## 必须等待需求澄清后才能定型的部分

不要直接决定最终 RTL 结构。
