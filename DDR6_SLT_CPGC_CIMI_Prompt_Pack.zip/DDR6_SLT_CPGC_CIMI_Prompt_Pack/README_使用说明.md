# DDR6 SLT / CPGC 类算法代码需求提炼提示词包

## 目的

本提示词包用于让算法同事把现有算法代码交给 Cimi 分析，反向提炼出未来 FPGA-based DDR6 SLT 平台所需的功能需求。

当前模块不要简单定义为传统 ALPG，更接近以下能力的组合：

- CPGC
- Memory Traffic Generator
- Pattern Generator
- Test Sequence Engine
- Memory Test / Checker

本轮重点不是让 Cimi 直接设计 RTL，而是先把：

**算法代码 → 测试行为 → FPGA需求 → Algorithm/MC边界**

梳理清楚。

---

## 推荐执行顺序

### 第 1 步
运行：

`01_CIMI_代码需求提炼_主提示词.md`

产出完整代码功能地图、测试序列、地址生成、Pattern、Checker、配置参数、需求表和 Open Questions。

### 第 2 步
运行：

`02_CIMI_需求攻击式复核.md`

针对第一轮输出做攻击式审核，重点找：

- 需求误判
- 隐藏状态
- 顺序依赖
- Expected Data 对齐问题
- Outstanding Read 关联问题
- Reset / Stop / Pause 边界
- Error Capture / Counter / Overflow
- FPGA 架构 Blocker

### 第 3 步
运行：

`03_CIMI_Algorithm_MC边界专项.md`

明确：

Software
→ Test Control / Algorithm
→ Pattern & Traffic Generation
→ Request Interface
→ DDR6 MC
→ PHY
→ DDR6 DRAM

各层职责。

---

## 最终优先回传给 FPGA/MC 方案设计人员的文件

优先提供：

1. `08_REQUIREMENTS.csv`
2. `09_ALGORITHM_MC_BOUNDARY.md`
3. `10_OPEN_QUESTIONS.md`
4. `02_TEST_SEQUENCE.md`
5. 攻击式复核结果

拿到这些后，就可以开始 DDR6 SLT 的 CPGC/Pattern Generator/Sequence Engine/Checker 架构设计。

---

## 原则

- 不允许 Cimi 根据“DDR 测试常识”自行补需求。
- 所有结论尽量回到代码文件、函数、行号。
- 区分：
  - CODE_CONFIRMED
  - INFERRED
  - UNKNOWN
- 软件实现细节不能直接当成硬件需求。
- 软件线程数、Queue、Buffer 等不能直接映射成 FPGA 并行度。
- 必须重点识别算法到底需要“Memory Transaction 顺序”，还是“DDR Command 顺序”。
