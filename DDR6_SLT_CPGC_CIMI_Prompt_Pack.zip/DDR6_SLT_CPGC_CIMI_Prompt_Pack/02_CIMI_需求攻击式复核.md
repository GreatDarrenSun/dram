# Cimi 需求提炼结果攻击式复核提示词

现在不要重新分析项目，也不要提出新的 FPGA 设计方案。

你的任务是攻击式审核上一轮生成的 Requirements。

逐条回到源代码检查以下问题：

1. 有没有把“代码实现细节”错误地写成“产品需求”？
2. 有没有把软件为了性能使用的线程、Queue、Buffer错误映射成硬件必须存在的能力？
3. 有没有凭 DDR/ALPG/CPGC 常识自行添加代码中不存在的需求？
4. 有没有遗漏跨函数、跨对象保存的状态？
5. 有没有遗漏 Seed、Counter、Index、Loop、Phase 等影响后续行为的状态？
6. 有没有遗漏 Reset、Stop、Restart、Pause 后这些状态如何变化？
7. Address Generator 是否真的可以根据当前配置完整重放地址序列？
8. Pattern Generator 是否真的可以根据 Seed/Address/State重现数据？
9. Read Data 返回后，Expected Data 是怎样与它重新对应起来的？
10. 如果存在多个 Outstanding Read，代码如何知道返回数据属于哪一笔事务？
11. 是否存在软件默认“请求一定按顺序返回”的隐藏假设？
12. Compare 是否存在 Byte/Bit Mask？
13. Error 信息是否存在丢弃、覆盖或最大保存数量？
14. Counter 是否存在位宽/溢出问题？
15. Loop到底是 Test Loop、Pattern Loop、Address Loop还是多层Loop？
16. Test Sequence 中是否存在条件跳转？
17. 是否存在上一笔操作结果影响下一笔操作？
18. 算法是否真正要求精确 DDR Command 顺序，还是只要求Memory Transaction顺序？
19. 哪些行为必须由 MC 保证，而不是 Test Engine保证？
20. 哪些 Requirement 没有足够代码证据？

对发现的问题不要直接修改成你认为正确的需求。

输出：

| ISSUE_ID | 原REQ | 问题 | 代码证据 | 严重度 | 建议处理 |
|---|---|---|---|---|---|

严重度：

- BLOCKER：不解决无法进行 FPGA 架构设计
- HIGH：可能导致架构返工
- MEDIUM：影响接口/寄存器/资源设计
- LOW：文档质量问题

最后重新给出：

`ARCHITECTURE_BLOCKERS`

只列真正影响下一阶段 FPGA 架构设计的问题。
