# Algorithm / Test Engine 与 DDR6 MC 边界专项确认提示词

基于代码分析结果，单独做一次 Algorithm/Test Engine 与 DDR6 MC 边界审查。

不要设计 RTL。

针对下面每项给出：

`ALGORITHM_OWNED / MC_OWNED / SHARED / UNKNOWN`

并提供代码证据和理由。

检查项：

- Test Phase
- Test Sequence
- Address Range
- Address Traversal
- Pattern Generation
- Expected Data
- Read/Write选择
- Read/Write顺序
- Read/Write比例
- Transaction Dependency
- Outstanding控制
- Read返回关联
- Data Compare
- Error Capture
- Error Statistics
- Rank选择
- Bank选择
- Row选择
- Column选择
- ACT生成
- PRE生成
- RD生成
- WR生成
- Refresh
- DDR Timing Constraint
- Command Arbitration
- Bank状态管理
- Row-hit/Row-miss处理
- DDR Command Encoding
- DFI控制
- PHY Timing
- Training
- Test Start/Stop
- Pause/Resume
- Timeout
- Interrupt
- Performance Counter

最终画出逻辑边界：

```text
Software
    ↓
Test Control / Algorithm
    ↓
Pattern & Traffic Generation
    ↓
???????? interface
    ↓
DDR6 MC
    ↓
DFI / PHY
    ↓
DDR6 DRAM
```

重点回答：

## Q1

`???????? interface` 当前最接近什么？

不要设计新接口，只分析代码当前隐含的抽象层级。

## Q2

如果算法要求：

“先写整个地址空间，再反向读取比较”

这种顺序是 Test Engine 的职责还是 MC 的职责？

## Q3

如果算法要求：

“对同一个Bank连续进行特定访问”

它真正要求的是：

- 特定Memory Transaction顺序
还是
- 特定ACT/RD/WR/PRE命令序列？

必须从代码判断。

## Q4

列出所有“如果MC自由调度可能破坏算法语义”的场景。

## Q5

列出所有“算法实际上不关心DDR底层命令，可以完全交给MC处理”的场景。

最终形成：

`ALGORITHM_MC_CONTRACT.md`

这一文件只描述双方功能责任和语义约束，不描述RTL结构。
