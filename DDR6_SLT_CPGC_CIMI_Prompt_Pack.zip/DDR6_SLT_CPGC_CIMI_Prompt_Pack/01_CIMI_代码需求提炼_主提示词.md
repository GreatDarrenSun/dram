# DDR6 SLT Pattern Generator 代码需求提炼提示词

## 使用目标

当前代码实现的是 DDR/Memory Test 相关的算法能力。最终需要将这些算法能力迁移或映射到 FPGA-based DDR6 SLT 平台。

注意：

- 当前模块不要简单定义为传统 ALPG。
- 它更接近 **CPGC / Memory Traffic Generator / Pattern Generator / Test Sequence Engine**。
- 本轮任务不是设计 RTL，不是修改代码，也不是直接给 FPGA 架构方案。
- 本轮唯一目标是：**从现有算法代码中，反向提炼出完整、可追溯、可用于 FPGA 架构设计的需求。**

必须严格区分：

1. `CODE_CONFIRMED`：代码中有明确实现或调用证据。
2. `INFERRED`：根据上下文推断，但代码没有完全证明。
3. `UNKNOWN`：当前代码无法确定，需要算法负责人确认。

禁止为了让文档完整而自行补需求。

---

# 第一轮：代码全景扫描与功能地图

请完整扫描当前工程，不修改任何代码。

首先回答：

## 1. 软件整体在解决什么问题

用硬件工程师能够理解的语言描述：

- 软件输入是什么？
- 软件输出是什么？
- 一次完整测试是怎样启动的？
- 怎样结束？
- 测试过程中有哪些阶段？
- 哪些模块负责生成测试内容？
- 哪些模块负责生成地址？
- 哪些模块决定 Read / Write？
- 哪些模块负责数据 Pattern？
- 哪些模块负责结果判断？
- 哪些模块负责错误统计？
- 哪些模块只是软件管理功能，与未来 FPGA 硬件无关？

不要照抄类名、函数名。

需要解释成真实行为。

例如不要只写：

`PatternManager::run()`

而要写成类似：

“根据当前 Pattern 配置生成一组写数据，在指定地址范围执行写入，并在后续读取阶段生成对应 Expected Data 用于比较。”

---

## 2. 给出代码功能地图

输出：

| 功能模块 | 源文件/类/函数 | 实际功能 | 输入 | 输出 | 内部状态 | 是否可能需要 FPGA 实现 | 证据 |
|---|---|---|---|---|---|---|---|

重点寻找以下功能，但不要假设代码一定存在：

- Test Sequence
- Address Generation
- Data Pattern Generation
- Read/Write Generation
- Loop控制
- Random/PRBS
- Expected Data Generation
- Read Data Compare
- Error Detection
- Error Counter
- Fail Address Capture
- Test Control
- Trigger
- Timeout
- Pause/Resume
- 多通道/多Rank/多Bank控制
- 配置管理
- Result/Log/Statistics

---

# 第二轮：还原“测试是怎么跑起来的”

不要按照软件函数调用树描述。

请从“Memory Test执行流程”的角度还原。

至少选出代码中 5~10 个有代表性的测试场景，逐个写成时序步骤。

例如：

```text
Step 1：配置地址范围
Step 2：选择地址生成方式
Step 3：选择 Data Pattern
Step 4：对地址 A 写入 Pattern X
Step 5：切换到下一地址
Step 6：……
Step N：重新读取地址 A
Step N+1：生成 Expected Data
Step N+2：Compare
Step N+3：记录错误地址
```

如果真实代码不是这样，以代码为准。

每个测试场景必须说明：

- 地址变化规律
- Read/Write顺序
- Data变化规律
- 循环方式
- 是否存在方向：
  - Low → High
  - High → Low
  - Random
- 是否存在地址相关数据
- 是否存在上一笔操作影响下一笔操作
- 是否存在固定等待时间
- 是否有 Repeat / Loop
- 是否有条件跳转
- Error 后继续还是停止

特别识别：

> 软件只是生成“Read/Write事务”，还是已经规定了 DDR ACT/RD/WR/PRE 等命令级序列？

这点必须单独给出结论和代码证据。

---

# 第三轮：专项分析——Address Generator

系统分析所有地址生成逻辑。

不要只列变量名。

我要知道算法真实支持哪些 Address Pattern。

至少检查：

- 起始地址
- 结束地址
- 地址 Mask
- 地址 Range
- Increment
- Decrement
- Stride
- Wrap
- Repeat
- Random Address
- PRBS/LFSR Address
- 固定地址
- 地址跳变
- 地址位翻转
- Walking Address
- 地址嵌套循环
- Bank切换
- Row切换
- Column切换
- Rank切换

如果软件存在物理 DRAM 地址拆分，继续分析：

```text
Channel
Sub-channel
Rank
Bank Group
Bank
Row
Column
Burst/Offset
```

输出每种 Address Mode：

| Addr Mode | 数学规则 | 初始条件 | 下一地址计算 | Wrap条件 | 配置参数 | 代码证据 |
|---|---|---|---|---|---|---|

如果存在地址映射：

必须说明：

```text
Linear Address
      ↓
Channel/Rank/Bank/Row/Column
```

之间具体怎样转换。

---

# 第四轮：专项分析——Data Pattern Generator

寻找所有数据生成算法。

至少检查：

- All 0
- All 1
- Checkerboard
- Inverse Checkerboard
- Walking 1
- Walking 0
- Fixed Pattern
- User Pattern
- Increment Pattern
- Address-as-Data
- Inverted Address
- PRBS
- LFSR
- Random
- Toggle Pattern
- 相邻bit相关Pattern
- 相邻Byte相关Pattern
- Burst内Pattern变化
- 不同地址Pattern变化

每种模式输出：

| Pattern | 生成公式/算法 | Seed | 状态 | 每周期是否变化 | 每地址是否变化 | Expected Data 如何恢复 | 代码证据 |
|---|---|---|---|---|---|---|---|

特别分析：

### Expected Data 是怎么来的？

判断属于哪一种：

A. Read 时重新计算 Expected Data  
B. Write Data 被存储下来  
C. 根据 Address + Seed 重建  
D. Pattern Generator 保留内部状态  
E. 其他方式

这一点直接影响未来 FPGA 架构，必须给出明确证据。

---

# 第五轮：专项分析——Read / Write / Test Sequence

系统提炼测试序列能力。

检查是否支持：

- Write only
- Read only
- Write → Read
- Write → Read → Compare
- Read → Modify → Write
- 多次Write后Read
- Write/Read交替
- N Write : M Read
- 单地址多次操作
- 多地址扫描
- 多Phase测试
- Loop
- 无限循环
- 指定次数循环
- 指定时间运行
- Stop on Error
- Continue on Error

重点寻找类似 March Algorithm 的行为，但不要因为代码像 March 就直接命名成 March。

首先描述真实操作：

```text
↑(w0)
↑(r0,w1)
↓(r1,w0)
...
```

然后再说明：

“该行为与某类 March Test 类似”。

---

# 第六轮：分析“算法层”和“DDR Controller层”的边界

这是本轮最重要的输出之一。

从代码证明：

当前算法到底控制到哪一级？

请区分：

### Level 1：测试意图

例如：

```text
测试整个地址空间
使用Pattern A
循环100次
```

### Level 2：Memory Transaction

例如：

```text
WRITE address X data Y
READ address X
```

### Level 3：DRAM Command

例如：

```text
ACT
RD
WR
PRE
REF
```

### Level 4：DDR PHY/DFI

例如：

```text
DFI command/data/control
```

给出：

```text
现有算法实际控制层级 = ?
```

并回答：

哪些事情算法要求必须自己决定？

哪些事情可以交给 MC？

例如：

```text
地址遍历                Algorithm
Read/Write顺序          Algorithm
ACT/PRE插入             MC
tRCD/tRP/tRAS检查       MC
Refresh                 MC
PHY timing              PHY
```

这里不要预设答案，以代码为准。

---

# 第七轮：结果检查与故障信息

分析所有 Checker / Compare / Error 相关代码。

检查：

- Expected Data
- Actual Data
- Compare Mask
- Byte Mask
- Bit Mask
- Error Bit Map
- Error Counter
- First Error
- Last Error
- Fail Address
- Fail Data
- Expected Data
- Error Timestamp
- Error Phase
- Error Pattern
- Error Bank/Row/Column
- Overflow处理
- Stop-on-error
- Error Threshold

输出：

| 能力 | 行为 | 保存信息 | 深度/数量限制 | 清除条件 | 代码证据 |
|---|---|---|---|---|---|

特别判断：

FPGA是否只需要返回：

```text
PASS / FAIL
```

还是软件实际上依赖：

```text
Fail Address
Expected Data
Actual Data
Bit Error Map
Pattern ID
Loop ID
Phase ID
```

---

# 第八轮：配置参数全集

扫描：

- 配置结构体
- Config Class
- JSON/XML/YAML
- CLI参数
- API参数
- Register定义
- 常量
- Enum
- Macro

形成完整配置表：

| REQ_ID | 参数 | 软件名称 | 实际含义 | 类型 | 位宽需求 | 默认值 | 合法范围 | 是否运行时可改 | 代码证据 |
|---|---|---|---|---|---|---|---|---|---|

注意：

“位宽需求”如果代码无法证明，则写：

`TBD`

不要猜。

---

# 第九轮：并发能力与性能要求

从代码中寻找：

- 多Channel
- 多Rank
- 多Bank
- 多线程
- Queue
- Pipeline
- Outstanding
- Batch
- Buffer
- FIFO
- Cache
- Async
- 并行 Compare

不要简单把软件线程数映射成 FPGA 并行度。

需要判断软件并发到底代表：

A. 性能优化  
B. 算法必须并行  
C. 多Memory实例  
D. 多测试实例  
E. 与硬件无关

如果代码存在明确性能假设，提取：

- 最大吞吐
- 最小吞吐
- 每秒操作数
- 测试时间
- Buffer Size
- Queue Depth
- Batch Size

代码没有证据就写 UNKNOWN。

---

# 第十轮：最终转换成“硬件需求”

基于前面的代码证据，将软件行为重新表达成 FPGA/RTL 可以设计的需求。

禁止描述具体 RTL 实现。

例如：

错误：

> 使用一个32深度FIFO保存地址。

因为这已经是在设计方案。

正确：

> 当连续错误产生速度高于软件读取速度时，硬件需要保证错误信息不丢失，所需缓存深度目前代码无法确定。

---

每条需求使用：

```text
REQ-xxx

需求名称：
需求类别：

需求描述：

触发条件：

输入：

要求行为：

输出：

状态/上下文：

配置参数：

边界条件：

异常行为：

性能要求：

与MC关系：

与PHY关系：

代码证据：

证据等级：
CODE_CONFIRMED / INFERRED / UNKNOWN

待确认问题：
```

---

# 第十一轮：重点输出未来 FPGA 可能需要的功能模块

这里只做“能力分组”，不要进行 RTL 架构设计。

例如检查是否存在以下能力：

```text
Test Control
Sequence Control
Address Generator
Data Pattern Generator
Expected Data Generator
Read/Write Request Generator
Compare Engine
Error Capture
Statistics
Configuration
Status
Trigger
```

对于每一个能力回答：

1. 为什么需要？
2. 哪些 Requirement 支撑？
3. 是否必须 FPGA 实时执行？
4. 是否可以软件执行？
5. 是否存在实时性要求？
6. 与 MC 的边界是什么？

---

# 第十二轮：必须主动寻找需求缺口

不能只总结代码已有内容。

站在未来 FPGA-based DDR6 SLT 的角度检查：

### 软件代码没有回答、但 FPGA 架构设计必须知道的问题。

至少检查：

- Test Engine 数量？
- 多Channel是否独立运行？
- 多Rank是否独立运行？
- 是否允许不同Channel跑不同Pattern？
- Pattern切换是否允许动态进行？
- Address Generator数量？
- Pattern Generator数量？
- Compare是否必须线速？
- 最大DDR数据吞吐下能否实时Compare？
- Fail信息需要保存多少条？
- Error Counter会不会溢出？
- Loop最大次数？
- Seed位宽？
- Test是否支持暂停恢复？
- Test停止时是否必须完成Outstanding事务？
- 配置更新什么时候生效？
- 是否需要Shadow配置？
- Reset后的状态？
- 测试中Reset怎么办？
- 多Engine之间需要同步吗？
- 是否需要Barrier？
- 是否需要外部Trigger？
- 是否需要超时？
- 软件轮询还是中断？
- 一次测试最长可能运行多久？
- Counter位宽怎么确定？

这些如果代码没有答案：

不要自行回答。

统一进入：

`OPEN QUESTION`

---

# 最终交付文件

请生成以下结果：

## 01_CODE_FUNCTION_MAP.md

代码功能地图。

## 02_TEST_SEQUENCE.md

完整测试行为及代表性测试序列。

## 03_ADDRESS_GENERATION.md

所有地址生成算法。

## 04_DATA_PATTERN.md

所有数据Pattern及Expected Data生成方式。

## 05_RW_SEQUENCE.md

Read/Write/Test Sequence能力。

## 06_CHECKER_AND_ERROR.md

Compare、Error Capture、Statistics能力。

## 07_CONFIGURATION.csv

全部可配置参数。

## 08_REQUIREMENTS.csv

最重要。

字段至少：

```text
REQ_ID
Category
Requirement
Trigger
Input
Behavior
Output
Configuration
Boundary
Performance
Evidence_File
Evidence_Function
Evidence_Line
Evidence_Level
Open_Question
```

## 09_ALGORITHM_MC_BOUNDARY.md

明确：

```text
Algorithm / Test Engine
        ↓
MC
        ↓
PHY
        ↓
DDR6
```

每一层分别负责什么。

## 10_OPEN_QUESTIONS.md

把所有不能从代码证明、但 FPGA 设计必须确认的问题集中列出。

每个问题说明：

```text
QUESTION
为什么必须确认
影响哪个Requirement
如果选A会怎样
如果选B会怎样
当前代码能提供什么证据
建议找谁确认
```

---

# 最终总结

最后只用 1~2 页内容回答以下问题：

### 1.
这个软件算法从本质上到底是什么？

不要用项目内部名字解释。

### 2.
它更接近：

- ALPG
- CPGC
- Memory Traffic Generator
- Memory BIST
- Pattern Generator
- Test Sequence Engine
- 上述能力的组合

说明原因。

### 3.
如果迁移到 FPGA，真正必须进入实时硬件数据通路的能力有哪些？

### 4.
哪些能力继续放软件里更合适？

### 5.
目前阻止 FPGA 架构设计的 Top 10 未决问题是什么？

所有结论必须能够回到代码证据。

不要因为“DDR测试一般应该这样”而补充代码中不存在的功能。
